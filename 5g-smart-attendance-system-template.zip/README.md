# 5G Smart Attendance System

This project contains the components to run a 5G-enabled face recognition attendance system using edge computing.